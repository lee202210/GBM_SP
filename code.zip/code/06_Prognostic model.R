####################### KEGG通路评分与风险评分的相关性分析
# library('GSVA')
# library(GSEABase)
# gmtFile='c2.cp.kegg.v7.4.symbols.gmt'
# c2KEGG <- getGmt(gmtFile,
#                  collectionType=BroadCollection(category="c2"),
#                  geneIdType=SymbolIdentifier())
# tcga.kegg.ssgsea <- gsva(as.matrix(gbm.tcga.t.exp), 
#                          c2KEGG,
#                          method = 'ssgsea',
#                          min.sz = 10,
#                          max.sz = 500,
#                          verbose = TRUE)
load('GSVA/tcga.kegg.ssgsea.RData')
load('GSVA/tcga.exp.h.all.RData')
tcga.kegg.ssgsea=tcga.kegg.ssgsea[,names(tcga.risk.score)]
dim(tcga.kegg.ssgsea)

tcga.exp.h.all=tcga.exp.h.all[,names(tcga.risk.score)]
dim(tcga.exp.h.all)

sort(-abs(cor(t(tcga.kegg.ssgsea),(as.numeric(tcga.risk.score)))))[1:32]

sum(abs(cor(t(tcga.kegg.ssgsea),(as.numeric(tcga.risk.score))))>=0.4)

tcga.ARS.pathway <- rownames(tcga.kegg.ssgsea[order(abs(cor(t(tcga.kegg.ssgsea),(tcga.risk.score))),
                                                    decreasing=TRUE)[1:15],order(tcga.risk.score)])

tcga.ARS.pathway_datas <- t(tcga.kegg.ssgsea[tcga.ARS.pathway, ])
tcga.ARS.pathway_datas <- crbind2DataFrame(tcga.ARS.pathway_datas)
tcga.ARS.pathway_datas$ARS.score <- tcga.risk.score

Heatmap(as.matrix(t(scale(t(tcga.kegg.ssgsea[tcga.ARS.pathway,rownames(tcga.subtype.ARS)]))))
        , name = "Expr"
        , cluster_rows = T
        , show_row_dend = F
        , column_split = tcga.subtype.ARS$Cluster
        , cluster_columns = T
        , cluster_column_slices=T
        , show_column_dend = F
        , show_column_names = F
        # , col = circlize::colorRamp2(c(-4, 0, 4), c('#3B4992FF', 'white', '#EE0000FF'))
        , column_title_gp = gpar(fill = (ggsci::pal_lancet("lanonc")(9))[c(7,4,3)])
        , border = TRUE
)
#################### HALLMARK
sort(-abs(cor(t(tcga.exp.h.all),(as.numeric(tcga.risk.score)))))[1:32]

tcga.ARS.pathway <- rownames(tcga.exp.h.all[order(abs(cor(t(tcga.exp.h.all),(tcga.risk.score))),
                                                  decreasing=TRUE)[1:24],order(tcga.risk.score)])

tcga.ARS.pathway_datas <- t(tcga.exp.h.all[tcga.ARS.pathway, ])
tcga.ARS.pathway_datas <- crbind2DataFrame(tcga.ARS.pathway_datas)
tcga.ARS.pathway_datas$SRS.score <- tcga.risk.score

Heatmap(as.matrix(t(scale(t(tcga.exp.h.all[tcga.ARS.pathway,rownames(tcga.subtype.ARS)]))))
        , name = "ssgsea scores"
        , cluster_rows = T
        , show_row_dend = F
        , column_split = tcga.subtype.ARS$Cluster
        , cluster_columns = T
        , cluster_column_slices=T
        , show_column_dend = F
        , show_column_names = F
        # , col = circlize::colorRamp2(c(-4, 0, 4), c('#3B4992FF', 'white', '#EE0000FF'))
        , column_title_gp = gpar(fill = (ggsci::pal_lancet("lanonc")(9))[c(7,4,3)])
        , border = TRUE
)


######### 免疫特征
load('immune/tcga.exp.cibersort.RData')
load('immune/tcga.exp.immu.ssgsea.RData')
load('immune/tcga.exp.xcell.RData')
load('immune/tcga.exp.estimate.RData')

tcga.exp.cibersort=get.IOBR.immu.format(tcga.exp.cibersort)
tcga.exp.xcell=get.IOBR.immu.format(tcga.exp.xcell)
tcga.exp.estimate=get.IOBR.immu.format(tcga.exp.estimate)

get_PlotMutiBoxplot(tcga.exp.cibersort[rownames(tcga.subtype.ARS),]
                          ,tcga.subtype.ARS
                          ,group_cols=ggsci::pal_npg()(9)[c(1, 2)])
########
get_PlotMutiBoxplot(tcga.exp.estimate[rownames(tcga.subtype.ARS),1:3]
                          ,tcga.subtype.ARS
                          ,group_cols=ggsci::pal_npg()(9)[c(1, 2)])


##########
x_matrix=cbind(tcga.exp.cibersort[names(tcga.risk.score),1:22],SRS.score=tcga.risk.score)

Heatmap(as.matrix(t(scale(tcga.exp.cibersort[names(tcga.risk.score),1:22])))
        , name = "Expr"
        , cluster_rows = T
        , show_row_dend = F
        , column_split = tcga.subtype.ARS$Cluster
        , cluster_columns = T
        , cluster_column_slices=T
        , show_column_dend = F
        , show_column_names = F
        # , col = circlize::colorRamp2(c(-4, 0, 4), c('#3B4992FF', 'white', '#EE0000FF'))
        , column_title_gp = gpar(fill = (ggsci::pal_lancet("lanonc")(9))[c(7,4,3)])
        , border = TRUE
)

############################### 免疫治疗
####### 免疫检查点抑制
immunosuppression.genes=c('ADORA2A','ARHGEF5','BTLA','CD160','CD244','CD27','CD274','CD276','CD47','CD80','CEACAM1','CTLA4','GEM','HAVCR2','ICOS','IDO1','LAG3','PDCD1','TNFSF4','VISTA','VTCN1')
length(immunosuppression.genes)

################## 亚型之间差异表达分析
gbm.tcga.t.exp_use=gbm.tcga.t.exp
dim(gbm.tcga.t.exp_use)

tcga.deg.c1$Summary
tcga.deg.c2$Summary
tcga.deg.c3$Summary
tcga.deg.c4$Summary

writeMatrix(tcga.deg.c1$DEG,'files/文件/tcga.deg.c1.txt')
writeMatrix(tcga.deg.c2$DEG,'files/文件/tcga.deg.c2.txt')
writeMatrix(tcga.deg.c3$DEG,'files/文件/tcga.deg.c3.txt')
writeMatrix(tcga.deg.c4$DEG,'files/文件/tcga.deg.c4.txt')

tcga.deg.c1$Summary
tcga.deg.c2$Summary
tcga.deg.c3$Summary
tcga.deg.c4$Summary

tcga.deg.c1.sig=get_DEG(tcga.deg.c1,logfc.cutoff=log2(1.5),p.cutoff = 0.05)
tcga.deg.c2.sig=get_DEG(tcga.deg.c2,logfc.cutoff=log2(1.5),p.cutoff = 0.05)
tcga.deg.c3.sig=get_DEG(tcga.deg.c3,logfc.cutoff=log2(1.5),p.cutoff = 0.05)
tcga.deg.c4.sig=get_DEG(tcga.deg.c4,logfc.cutoff=log2(1.5),p.cutoff = 0.05)

all.deg.sig=Reduce(union,list(rownames(tcga.deg.c1.sig)
                              ,rownames(tcga.deg.c2.sig)
                              , rownames(tcga.deg.c3.sig)
                              , rownames(tcga.deg.c4.sig)))
length(all.deg.sig)

writeMatrix(all.deg.sig,'files/文件/all.deg.sig.txt.txt')

########## 单因素Cox分析
createCoxModel_use=function(dat,time,event,isStep=F,direction=c("both", "backward", "forward")[1],check=T){
  cls=colnames(dat)
  dat1=cbind(dat,time,event)
  colnames(dat1)=c(paste0('g',1:ncol(dat)),'time','status')
  dat1=as.data.frame(dat1)
  if(ncol(dat)>nrow(dat)&check){
    print('gene count > sample count')
    return(NULL)
  }
  #nas=apply(dat1, 1, function(x){
  #  return(sum(is.na(x)))
  #})
  #dat1=dat1[which(nas==0),]
  
  fmla <- as.formula(paste0("Surv(time, status) ~",paste0(colnames(dat1)[1:ncol(dat)],collapse = '+')))
  library(survival)
  cox <- coxph(fmla, data = dat1)
  
  if(isStep){
    tryCatch({
      cox=step(cox,direction =direction,steps = 10000)
    },error = function(e) {
      print(conditionMessage(e))
      return(NULL)
    })
  }
  #score=predict(cox,data=dat1)
  sig.genes=cls[as.numeric(gsub('g','',names(cox$coefficients)))]
  fls=c('RiskScore=')
  for(i in 1:length(sig.genes)){
    if(cox$coefficients[i]>0){
      fls=c(fls,'+',round(cox$coefficients[i],3),'*',sig.genes[i])
    }else{
      fls=c(fls,round(cox$coefficients[i],3),'*',sig.genes[i])
    }
  }
  score=predictRiskScore(cox$coefficients,sig.genes,dat)
  return(list(Cox=cox,Score=score,Genes=sig.genes,Coef=cox$coefficients,fmla=paste0(fls,collapse = '')))
}

length(all.deg.sig)

tcga.cox=cox_batch(t(scale(t(gbm.tcga.t.exp[(all.deg.sig),])))
                   ,time = gbm.tcga.t.exp.os$OS.time
                   ,event = gbm.tcga.t.exp.os$OS)

table(tcga.cox$p.value<0.05)
table(tcga.cox$p.value<0.01)
table(tcga.cox$p.value<0.001)

############
p.cutoff=0.01
tcga.cox_use=tcga.cox
tcga.cox_use$coef=log(tcga.cox_use$HR)
tcga.cox_use$Gene=rownames(tcga.cox_use)
tcga.cox_use$type=rep('None',nrow(tcga.cox_use))
tcga.cox_use$type[which(tcga.cox_use$p.value<p.cutoff & tcga.cox_use$coef>0)]='Risk'
tcga.cox_use$type[which(tcga.cox_use$p.value<p.cutoff & tcga.cox_use$coef<0)]='Protective'

table(tcga.cox_use$type)

p1 <- ggplot(data = tcga.cox_use,
             aes(x = coef,
                 y = -log10(p.value)))
p1=p1+geom_point(alpha=0.4, size=3.5, aes(color=type))
p1=p1+scale_color_manual(values=c(mg_colors[2],'grey',mg_colors[1]),limits = c("Protective",'None', "Risk"),name='State')
p1=p1+geom_hline(yintercept = -log10(p.cutoff),lty=4,col="black",lwd=0.8)
p1=p1+ylab('-log10(pvalue)')+xlab('Cox coefficient')
# p1=p1+ggrepel::geom_text_repel(data=module.genes.cox_use[which(module.genes.cox_use$p.value<0.05),],aes(label=Gene))
p1=p1+theme_bw()
p1=p1+theme(
  axis.text.y=element_text(family="Times",face="plain"), #设置y轴刻度标签的字体簇，字体大小，字体样式为plain
  axis.title.y=element_text(family="Times",face="plain"), #设置y轴标题的字体属性
  legend.text=element_text(face="plain", family="Times", colour="black"  #设置图例的子标题的字体属性
  ),
  legend.title=element_text(face="plain", family="Times", colour="black" #设置图例的总标题的字体属性
  ),
  legend.justification=c(1,1), legend.position=c(1,1)
  ,legend.background = element_rect(fill = NA, colour = NA)
)

table(tcga.cox_use$type)

######### lasso
tcga.gene.sig=rownames(tcga.cox)[which(tcga.cox$p.value<p.cutoff)]
length(tcga.gene.sig)

tcga.exp.sig=gbm.tcga.t.exp[tcga.gene.sig,]
tcga.exp.sig=t(tcga.exp.sig)
dim(tcga.exp.sig)

options(ggrepel.max.overlaps = Inf)
tcga.lasso.res=mg_lasso_cox_use(t((t(tcga.exp.sig)))
                                , time = gbm.tcga.t.exp.os$OS.time
                                , event = gbm.tcga.t.exp.os$OS
                                , nfolds = 10
                                , lambda.min = T
                                , figLabels=c('B','C'))
tcga.lasso.res$Genes

tcga.lasso.res$lambda

tcga.lasso.res$plot

tcga.exp.for.cox=gbm.tcga.t.exp[match(tcga.lasso.res$Genes,row.names(gbm.tcga.t.exp)),]
dim(tcga.exp.for.cox)

lst.modl=createCoxModel_use((t(tcga.exp.for.cox))
                            ,time = gbm.tcga.t.exp.os$OS.time
                            , event = gbm.tcga.t.exp.os$OS
                            , isStep = T)
lst.modl$Genes
lst.modl$fmla

lst.modl.Coef=lst.modl$Coef
names(lst.modl.Coef)=lst.modl$Genes
lst.modl.Coef

tcga.risk.score=lst.modl$Score
tcga.risk.score=mosaic::zscore(tcga.risk.score)
range(tcga.risk.score)
table(tcga.risk.score>0)

lst.modl$Coef

gene.coef=data.frame(Gene=lst.modl$Genes,Coef=lst.modl$Coef)
gene.coef$Type=ifelse(lst.modl$Coef>0,'Risk','Protective')
gene.coef$Type=factor(gene.coef$Type,levels=c('Risk','Protective'))
table(gene.coef$Type)

############### TCGA
tcga.cutoff <- survminer::surv_cutpoint(data.frame(time=gbm.tcga.t.exp.os$OS.time/365,
                                                   event=gbm.tcga.t.exp.os$OS,
                                                   risk=tcga.risk.score), time = "time", event = "event",
                                        variables = c("risk"))
tcga.cutoff=tcga.cutoff$cutpoint$cutpoint
tcga.cutoff=0

plotCoxModel_Batch_use(riskScore = tcga.risk.score
                             ,dat = t(tcga.exp.for.cox[match(lst.modl$Genes, row.names(tcga.exp.for.cox)), ])
                             , time = gbm.tcga.t.exp.os$OS.time/365
                             , event = gbm.tcga.t.exp.os$OS
                             , cutoff = tcga.cutoff
                             , mks = c(1, 2,3))
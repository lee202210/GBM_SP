#### CGGA 胶质瘤数据:DataSet ID: mRNAseq_693
gbm.cgga.exp.batch1=read.table("CGGA/CGGA.mRNAseq_693.RSEM-genes.20200506.txt"
                               ,row.names = 1,sep="\t",header=T,as.is=T,quote="\""
                               ,fill=T,check.names = F,stringsAsFactors = F)
dim(gbm.cgga.exp.batch1)

gbm.cgga.t.exp.batch1=gbm.cgga.exp.batch1

index1=rowMeans(gbm.cgga.t.exp.batch1==0)
inde.batch1=which(index1<=0.5)## 基因过滤
gbm.cgga.t.exp.batch1=gbm.cgga.t.exp.batch1[inde.batch1,]

dim(gbm.cgga.t.exp.batch1)

## 临床数据
gbm.cgga.t.exp.cli.batch1=read.table("CGGA/CGGA.mRNAseq_693_clinical.20200506.txt"
                                     ,row.names = 1,sep="\t",header=T,as.is=T,quote="\""
                                     ,fill=T,check.names = F,stringsAsFactors = F)
dim(gbm.cgga.t.exp.cli.batch1)

### pGBM 样本筛选
table(gbm.cgga.t.exp.cli.batch1$Histology)
# selected=c('A','AA','AO','AOA','O','OA')
selected=c('GBM')
gbm.cgga.t.exp.cli.batch1=gbm.cgga.t.exp.cli.batch1[which(gbm.cgga.t.exp.cli.batch1$Histology %in% selected),]
dim(gbm.cgga.t.exp.cli.batch1) ## 282 个样本

######### 生存时间
gbm.cgga.t.exp.os.batch1=gbm.cgga.t.exp.cli.batch1[,c('OS','Censor (alive=0; dead=1)')]
gbm.cgga.t.exp.os.batch1=reshape::rename(gbm.cgga.t.exp.os.batch1,c('Censor (alive=0; dead=1)'='OS'
                                                                    ,'OS'='OS.time'))
dim(gbm.cgga.t.exp.os.batch1)


gbm.cgga.t.exp.cli.batch1<-gbm.cgga.t.exp.cli.batch1[intersect(rownames(gbm.cgga.t.exp.cli.batch1)
                                                               ,colnames(gbm.cgga.t.exp.batch1)),]
dim(gbm.cgga.t.exp.cli.batch1)

gbm.cgga.t.exp.os.batch1<-gbm.cgga.t.exp.os.batch1[!is.na(gbm.cgga.t.exp.os.batch1$OS.time),]
gbm.cgga.t.exp.os.batch1<-gbm.cgga.t.exp.os.batch1[!is.na(gbm.cgga.t.exp.os.batch1$OS),]

############ 临床信息
gbm.cgga.t.exp.cli.tnm.batch1=gbm.cgga.t.exp.cli.batch1[,-match(c('OS','Censor (alive=0; dead=1)'),colnames(gbm.cgga.t.exp.cli.batch1))]
gbm.cgga.t.exp.cli.tnm.batch1<-gbm.cgga.t.exp.cli.tnm.batch1[rownames(gbm.cgga.t.exp.os.batch1),]
############ 表达谱
gbm.cgga.t.exp.batch1<-gbm.cgga.t.exp.batch1[,rownames(gbm.cgga.t.exp.os.batch1)]
dim(gbm.cgga.t.exp.batch1)

writeMatrix(gbm.cgga.t.exp.batch1,outpath = 'files/文件/gbm.cgga.t.exp.batch1.txt')
writeMatrix(gbm.cgga.t.exp.cli.tnm.batch1,outpath = 'files/文件/gbm.cgga.t.exp.cli.batch1.txt')

#######################################################
#######################################################
#### CGGA 胶质瘤数据:DataSet ID: mRNAseq_325
gbm.cgga.exp.batch2=read.table("CGGA/CGGA.mRNAseq_325.RSEM-genes.20200506.txt"
                               ,row.names = 1,sep="\t",header=T,as.is=T,quote="\""
                               ,fill=T,check.names = F,stringsAsFactors = F)
dim(gbm.cgga.exp.batch2)

gbm.cgga.t.exp.batch2=gbm.cgga.exp.batch2

index1=rowMeans(gbm.cgga.t.exp.batch2==0)
inde.batch2=which(index1<=0.5)## 基因过滤
gbm.cgga.t.exp.batch2=gbm.cgga.t.exp.batch2[inde.batch2,]

dim(gbm.cgga.t.exp.batch2)

## 临床数据
gbm.cgga.t.exp.cli.batch2=read.table("CGGA/CGGA.mRNAseq_325_clinical.20200506.txt"
                                     ,row.names = 1,sep="\t",header=T,as.is=T,quote="\""
                                     ,fill=T,check.names = F,stringsAsFactors = F)
dim(gbm.cgga.t.exp.cli.batch2)

### pGBM 样本筛选
table(gbm.cgga.t.exp.cli.batch2$Histology)

gbm.cgga.t.exp.cli.batch2=gbm.cgga.t.exp.cli.batch2[which(gbm.cgga.t.exp.cli.batch2$Histology %in% selected),]
dim(gbm.cgga.t.exp.cli.batch2)

######### 生存时间
gbm.cgga.t.exp.os.batch2=gbm.cgga.t.exp.cli.batch2[,c('OS','Censor (alive=0; dead=1)')]
gbm.cgga.t.exp.os.batch2=reshape::rename(gbm.cgga.t.exp.os.batch2,c('Censor (alive=0; dead=1)'='OS' ,'OS'='OS.time'))
dim(gbm.cgga.t.exp.os.batch2)

######## 生存时间筛选
gbm.cgga.t.exp.os.batch2<-gbm.cgga.t.exp.os.batch2[!is.na(gbm.cgga.t.exp.os.batch2$OS.time),]
gbm.cgga.t.exp.os.batch2<-gbm.cgga.t.exp.os.batch2[!is.na(gbm.cgga.t.exp.os.batch2$OS),]

######## 临床信息
gbm.cgga.t.exp.cli.tnm.batch2=gbm.cgga.t.exp.cli.batch2[,-match(c('OS','Censor (alive=0; dead=1)'),colnames(gbm.cgga.t.exp.cli.batch2))]
gbm.cgga.t.exp.cli.tnm.batch2<-gbm.cgga.t.exp.cli.tnm.batch2[rownames(gbm.cgga.t.exp.os.batch2),]
######## 表达谱
gbm.cgga.t.exp.batch2<-gbm.cgga.t.exp.batch2[,rownames(gbm.cgga.t.exp.os.batch2)]
dim(gbm.cgga.t.exp.batch2)

writeMatrix(gbm.cgga.t.exp.batch2,outpath = 'files/文件/gbm.cgga.t.exp.batch2.txt')
writeMatrix(gbm.cgga.t.exp.cli.tnm.batch2,outpath = 'files/文件/gbm.cgga.t.exp.cli.batch2.txt')

################# CGGA RNA-Seq合并
dim(gbm.cgga.t.exp.batch1)
dim(gbm.cgga.t.exp.batch2)

common.genes=intersect(row.names(gbm.cgga.t.exp.batch1),row.names(gbm.cgga.t.exp.batch2))
length(common.genes)

gbm.cgga.t.exp.merge=cbind(gbm.cgga.t.exp.batch1[common.genes,],gbm.cgga.t.exp.batch2[common.genes,])
cgga.batch=data.frame(batch=rep(c('mRNAseq_693','mRNAseq_325')
                                ,times=c(ncol(gbm.cgga.t.exp.batch1),ncol(gbm.cgga.t.exp.batch2))),stringsAsFactors = F)
rownames(cgga.batch)=c(colnames(gbm.cgga.t.exp.batch1),colnames(gbm.cgga.t.exp.batch2))

save(gbm.cgga.t.exp.merge,file='CGGA/gbm.cgga.t.exp.merge.RData')
save(cgga.batch,file='CGGA/cgga.batch.RData')
library(sva)
# gbm.cgga.t.exp.cmbt=ComBat(dat = as.matrix(log2(gbm.cgga.t.exp.merge+1))
#                       , batch = cgga.batch$batch
#                       , par.prior = F)
# 
# save(gbm.cgga.t.exp.cmbt,file='CGGA/gbm.cgga.t.exp.cmbt.RData')

load('CGGA/gbm.cgga.t.exp.cmbt.RData')

############# CGGA 合并后的数据
gbm.cgga.t.exp=gbm.cgga.t.exp.cmbt
gbm.cgga.t.exp.os=rbind(gbm.cgga.t.exp.os.batch1,gbm.cgga.t.exp.os.batch2)
gbm.cgga.t.exp.cli.tnm=rbind(gbm.cgga.t.exp.cli.tnm.batch1,gbm.cgga.t.exp.cli.tnm.batch2)

gbm.cgga.t.exp=gbm.cgga.t.exp[,rownames(gbm.cgga.t.exp.os)]
gbm.cgga.t.exp.cli.tnm=gbm.cgga.t.exp.cli.tnm[rownames(gbm.cgga.t.exp.os),]
gbm.cgga.t.exp.cli.tnm$Gender[gbm.cgga.t.exp.cli.tnm$Gender=='Female ']="Female"


cgga.t.exp=gbm.cgga.t.exp
cgga.t.exp.cli.tnm=gbm.cgga.t.exp.cli.tnm
cgga.t.exp.os=gbm.cgga.t.exp.os

############### CGGA batch1
cgga.t.cli_use.batch1=cbind(gbm.cgga.t.exp.os.batch1,gbm.cgga.t.exp.cli.tnm.batch1)
cgga.t.cli_use.batch2=cbind(gbm.cgga.t.exp.os.batch2,gbm.cgga.t.exp.cli.tnm.batch2)

cgga.t.cli_use.batch1=dplyr::rename(cgga.t.cli_use.batch1,c('IDH Mutation'='IDH_mutation_status'
                                                            ,'1p/19q co-deletion'='1p19q_codeletion_status'
                                                            ,'MGMT promoter methylation'='MGMTp_methylation_status'))

cgga.t.cli_use.batch1$`IDH Mutation`[which(cgga.t.cli_use.batch1$`IDH Mutation`=='Wildtype')]='WT'
cgga.t.cli_use.batch1$`MGMT promoter methylation`[which(cgga.t.cli_use.batch1$`MGMT promoter methylation`=='methylated')]='Methylated'
cgga.t.cli_use.batch1$`MGMT promoter methylation`[which(cgga.t.cli_use.batch1$`MGMT promoter methylation`=='un-methylated')]='Unmethylated'
table(cgga.t.cli_use.batch1$Gender)
cgga.t.cli_use.batch1$Gender[which(cgga.t.cli_use.batch1$Gender=='Female ')]='Female'
table(cgga.t.cli_use.batch2$Gender)

########### CGGA batch2
cgga.t.cli_use.batch2=dplyr::rename(cgga.t.cli_use.batch2,c('IDH Mutation'='IDH_mutation_status'
                                                            ,'1p/19q co-deletion'='1p19q_codeletion_status'
                                                            ,'MGMT promoter methylation'='MGMTp_methylation_status'))

cgga.t.cli_use.batch2$`IDH Mutation`[which(cgga.t.cli_use.batch2$`IDH Mutation`=='Wildtype')]='WT'
cgga.t.cli_use.batch2$`MGMT promoter methylation`[which(cgga.t.cli_use.batch2$`MGMT promoter methylation`=='methylated')]='Methylated'
cgga.t.cli_use.batch2$`MGMT promoter methylation`[which(cgga.t.cli_use.batch2$`MGMT promoter methylation`=='un-methylated')]='Unmethylated'

table(cgga.t.cli_use.batch2$Gender)

##################### TCGA数据集
########### GDC 下载数据处理
gbm.tcga.cli=readMatrix('TCGA/GDC/Merge_TCGA-GBM_clinical.txt',row = F)
dim(gbm.tcga.cli)
gbm.tcga.cli$Tumor_Sample_Barcode=gbm.tcga.cli$A0_Samples
gbm.tcga.cli$os=gbm.tcga.cli$A1_OS
gbm.tcga.cli$os_status=gbm.tcga.cli$A2_Event
dim(gbm.tcga.cli)
gbm.tcga.cli=gbm.tcga.cli[,c(125:127,1:124)]
names(table(gbm.tcga.cli$os_status))

gbm.tcga.cli$os_status[which(gbm.tcga.cli$os_status=='Dead')]=1
gbm.tcga.cli$os_status[which(gbm.tcga.cli$os_status=='Alive')]=0

gbm.tcga.cli=data.frame(SampleID=paste0(gbm.tcga.cli$Tumor_Sample_Barcode,"-01"),gbm.tcga.cli,stringsAsFactors = F,check.names = F)
rownames(gbm.tcga.cli)=gbm.tcga.cli$SampleID

###TCGA-GBM FPKM数据
# gbm.tcga.exp.fpkm=read.table("TCGA/Merge_TCGA-GBM_RNA_seq_FPKM.txt"
#                          ,row.names = 1,sep="\t",header=T,as.is=T,quote="\""
#                          ,fill=T,check.names = F,stringsAsFactors = F)
# head(rownames(gbm.tcga.exp.fpkm))
# gbm.tcga.exp.fpkm=log2(gbm.tcga.exp.fpkm+1)
# gbm.tcga.exp=exp_ensg2symbol(gbm.tcga.exp.fpkm,method = 'median')
# ###保存
# save(gbm.tcga.exp,file='TCGA/gbm.tcga.exp.RData')
################## TCGA 芯片数据
###################################### GBM 芯片数据
###TCGA-GBM 芯片数据
# gbm.tcga.exp=read.table("TCGA/TCGA.GBM.sampleMap_HT_HG-U133A/HT_HG-U133A"
#                          ,row.names = 1,sep="\t",header=T,as.is=T,quote="\""
#                          ,fill=T,check.names = F,stringsAsFactors = F)
# dim(gbm.tcga.exp)
# ###保存
# save(gbm.tcga.exp,file='TCGA/gbm.tcga.exp.RData')
load('TCGA/gbm.tcga.exp.RData')
dim(gbm.tcga.exp)
range(gbm.tcga.exp)
table(substr(colnames(gbm.tcga.exp),14,15))

######### -01 原发肿瘤样本
gbm.tcga.exp.t.inds=grep('-01[A-Z]?',colnames(gbm.tcga.exp))
length(gbm.tcga.exp.t.inds)

gbm.tcga.t.exp=gbm.tcga.exp[,gbm.tcga.exp.t.inds]
dim(gbm.tcga.t.exp)

##############################
gbm.tcga.t.cli=gbm.tcga.cli[grep("-01[AD]?",gbm.tcga.cli$SampleID),]
dim(gbm.tcga.t.cli)

gbm.tcga.t.cli=dplyr::distinct(gbm.tcga.t.cli,SampleID,.keep_all=TRUE)
rownames(gbm.tcga.t.cli)=gbm.tcga.t.cli$SampleID
dim(gbm.tcga.t.cli)

##########
setdiff(colnames(gbm.tcga.t.exp),gbm.tcga.t.cli$SampleID)

gbm.tcga.t.cli=gbm.tcga.t.cli[colnames(gbm.tcga.t.exp),]
dim(gbm.tcga.t.cli)

gbm.tcga.t.cli=dplyr::rename(gbm.tcga.t.cli,c('OS.time'='A1_OS'
                                              ,'OS'='A2_Event'))
table(gbm.tcga.t.cli$OS)

gbm.tcga.t.cli$OS[gbm.tcga.t.cli$OS=='Alive']=0
gbm.tcga.t.cli$OS[gbm.tcga.t.cli$OS=='Dead']=1
gbm.tcga.t.cli$OS[gbm.tcga.t.cli$OS=='']=NA
table(gbm.tcga.t.cli$OS)

gbm.tcga.t.cli=crbind2DataFrame(gbm.tcga.t.cli)

table(gbm.tcga.t.cli$OS)
table(is.na(gbm.tcga.t.cli$OS))
table(is.na(gbm.tcga.t.cli$OS.time))

gbm.tcga.t.cli<-gbm.tcga.t.cli[!is.na(gbm.tcga.t.cli$OS.time),]
gbm.tcga.t.cli<-gbm.tcga.t.cli[!is.na(gbm.tcga.t.cli$OS),]
dim(gbm.tcga.t.cli)

range(gbm.tcga.t.cli$OS.time)

table(gbm.tcga.t.cli$OS.time<30)
table(gbm.tcga.t.cli$OS.time>365*10)
table(gbm.tcga.t.cli$OS.time>365*15)

###
gbm.tcga.t.cli=gbm.tcga.t.cli[intersect(gbm.tcga.t.cli$SampleID,colnames(gbm.tcga.t.exp)), ]
dim(gbm.tcga.t.cli)
gbm.tcga.t.exp=gbm.tcga.t.exp[,gbm.tcga.t.cli$SampleID]
dim(gbm.tcga.t.exp)

## TCGA 生存数据
gbm.tcga.t.exp.os=gbm.tcga.t.cli[,c('OS','OS.time')]
gbm.tcga.t.exp.os=gbm.tcga.t.exp.os[which(gbm.tcga.t.exp.os$OS.time>0),]
dim(gbm.tcga.t.exp.os)

gbm.tcga.t.cli=gbm.tcga.t.cli[rownames(gbm.tcga.t.exp.os),]
gbm.tcga.t.exp=gbm.tcga.t.exp[,rownames(gbm.tcga.t.exp.os)]
dim(gbm.tcga.t.cli)
dim(gbm.tcga.t.exp)

gbm.tcga.t.exp=gbm.tcga.t.exp[which(apply(gbm.tcga.t.exp, 1, function(x){sum(x==0)<0.5*ncol(gbm.tcga.t.exp)})),]
dim(gbm.tcga.t.exp)

writeMatrix(gbm.tcga.t.cli,outpath = 'files/文件/gbm.tcga.t.cli.txt')
writeMatrix(gbm.tcga.t.exp,outpath = 'files/文件/gbm.tcga.t.exp.txt')

## TCGA 临床数据
gbm.tcga.t.exp.cli.tnm=clean_TNMStage(sex = gbm.tcga.t.cli$gender
                                      , age = gbm.tcga.t.cli$age_at_initial_pathologic_diagnosis
                                      , age_cut = NULL)
row.names(gbm.tcga.t.exp.cli.tnm)=rownames(gbm.tcga.t.cli)
dim(gbm.tcga.t.exp.cli.tnm)
colnames(gbm.tcga.t.exp.cli.tnm)

###########
## TCGA 分子数据
tcga.molecular.data
tcga.cli.selected=c('Case','IDH status','1p/19q codeletion','MGMT promoter status')
tcga.molecular.data=tcga.molecular.data[,tcga.cli.selected]

##########
tcga.t.exp.cli.tnm_use=gbm.tcga.t.exp.cli.tnm
tcga.t.exp.cli.tnm_use$sample=rownames(tcga.t.exp.cli.tnm_use)
tcga.t.exp.cli.tnm_use$Case=substr(rownames(tcga.t.exp.cli.tnm_use),1,12)
tcga.t.exp.cli.tnm_use=merge(tcga.t.exp.cli.tnm_use,tcga.molecular.data,by='Case',all.x=T,all.y=F)
rownames(tcga.t.exp.cli.tnm_use)=tcga.t.exp.cli.tnm_use$sample
tcga.t.exp.cli.tnm_use=tcga.t.exp.cli.tnm_use[rownames(gbm.tcga.t.exp.cli.tnm),]

tcga.t.cli_use=cbind(gbm.tcga.t.exp.os,tcga.t.exp.cli.tnm_use)
colnames(tcga.t.cli_use)

######
tcga.t.cli_use=dplyr::rename(tcga.t.cli_use,c('IDH Mutation'='IDH status'
                                              ,'1p/19q co-deletion'='1p/19q codeletion'
                                              ,'MGMT promoter methylation'='MGMT promoter status'))

colnames(tcga.t.cli_use)
table(tcga.t.cli_use$`IDH Mutation`)

table(tcga.t.cli_use$`1p/19q co-deletion`)
tcga.t.cli_use$`1p/19q co-deletion`[which(tcga.t.cli_use$`1p/19q co-deletion`=='non-codel')]='Non-codel'
tcga.t.cli_use$`1p/19q co-deletion`[which(tcga.t.cli_use$`1p/19q co-deletion`=='codel')]='Codel'

table(tcga.t.cli_use$`1p/19q co-deletion`)
tcga.t.cli_use$`1p/19q co-deletion`=factor(tcga.t.cli_use$`1p/19q co-deletion`,levels = c('Codel','Non-codel'))
table(tcga.t.cli_use$`1p/19q co-deletion`)

table(tcga.t.cli_use$`MGMT promoter methylation`)
colnames(tcga.t.cli_use)

getGeneFC=function(gene.exp,group,ulab=ulab,dlab=NULL){
  degs_C1_C3=mg_limma_DEG_use(gene.exp, 
                              group,
                              ulab = ulab,
                              dlab = dlab)
  table(degs_C1_C3$DEG$adj.P.Val<0.05)
  table(degs_C1_C3$DEG$adj.P.Val<0.01)
  
  ## 未过滤任何基因
  degs_C1_C3_sig<-degs_C1_C3$DEG[which(degs_C1_C3$DEG$adj.P.Val <= 1),]
  
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(stringr)
  
  degs_C1_C3_sig_gene<-rownames(degs_C1_C3_sig)
  
  # degs_gene_entz=bitr(degs_C1_C3_sig_gene,fromType="SYMBOL",toType="ENTREZID",OrgDb="org.Hs.eg.db")
  # degs_gene_entz <- dplyr::distinct(degs_gene_entz,SYMBOL,.keep_all=TRUE)
  # 
  gene_df <- data.frame(logFC=degs_C1_C3_sig$logFC,
                        SYMBOL = rownames(degs_C1_C3_sig))
  # gene_df <- merge(gene_df,degs_gene_entz,by="SYMBOL")
  head(gene_df)
  
  geneList<-gene_df$logFC
  names(geneList)=gene_df$SYMBOL 
  head(geneList)
  
  geneList=sort(geneList,decreasing = T)
  head(geneList) ## 降序排列
  return(geneList)
}

##############
tcga.t.exp=gbm.tcga.t.exp

tcga.geneList.c1=getGeneFC(gene.exp=tcga.t.exp,group=tcga.subtype$Cluster,ulab='C1',dlab = NULL)
tcga.geneList.c2=getGeneFC(gene.exp=tcga.t.exp,group=tcga.subtype$Cluster,ulab='C2',dlab = NULL)
tcga.geneList.c3=getGeneFC(gene.exp=tcga.t.exp,group=tcga.subtype$Cluster,ulab='C3',dlab = NULL)
tcga.geneList.c4=getGeneFC(gene.exp=tcga.t.exp,group=tcga.subtype$Cluster,ulab='C4',dlab = NULL)

kegmt<-read.gmt("origin_datas/h.all.v7.4.symbols.gmt")

tcga.hallmark.c1<-GSEA(tcga.geneList.c1,TERM2GENE = kegmt,seed=T,pvalueCutoff = 0.05)
tcga.hallmark.c2<-GSEA(tcga.geneList.c2,TERM2GENE = kegmt,seed=T,pvalueCutoff = 0.05)
tcga.hallmark.c3<-GSEA(tcga.geneList.c3,TERM2GENE = kegmt,seed=T,pvalueCutoff = 0.05)
tcga.hallmark.c4<-GSEA(tcga.geneList.c4,TERM2GENE = kegmt,seed=T,pvalueCutoff = 0.05)

########## 热图展示 异常的通路
tcga.hallmark.c1.res=tcga.hallmark.c1@result
tcga.hallmark.c2.res=tcga.hallmark.c2@result
tcga.hallmark.c3.res=tcga.hallmark.c3@result
tcga.hallmark.c4.res=tcga.hallmark.c4@result

dim(tcga.hallmark.c1.res)
dim(tcga.hallmark.c2.res)
dim(tcga.hallmark.c3.res)
dim(tcga.hallmark.c4.res)

hallmark.union=Reduce(union,list(rownames(tcga.hallmark.c1.res)
                                 ,rownames(tcga.hallmark.c2.res)
                                 ,rownames(tcga.hallmark.c3.res)
                                 ,rownames(tcga.hallmark.c4.res)))
length(hallmark.union)

hallmark.heatmap.dat=matrix(0,nrow = 4,ncol = length(hallmark.union))
rownames(hallmark.heatmap.dat)=c('C1','C2','C3','C4')
colnames(hallmark.heatmap.dat)=hallmark.union

hallmark.heatmap.dat[1,match(rownames(tcga.hallmark.c1.res),colnames(hallmark.heatmap.dat))]=tcga.hallmark.c1.res$NES
hallmark.heatmap.dat[2,match(rownames(tcga.hallmark.c2.res),colnames(hallmark.heatmap.dat))]=tcga.hallmark.c2.res$NES
hallmark.heatmap.dat[3,match(rownames(tcga.hallmark.c3.res),colnames(hallmark.heatmap.dat))]=tcga.hallmark.c3.res$NES
hallmark.heatmap.dat[4,match(rownames(tcga.hallmark.c4.res),colnames(hallmark.heatmap.dat))]=tcga.hallmark.c4.res$NES

## 热图
library(ComplexHeatmap)
Heatmap(as.matrix(hallmark.heatmap.dat)
              , name = "NES"
              , col = circlize::colorRamp2(c(-2, 0, 3), c('slateblue1', 'white', 'orange'))
              , border = TRUE
              , show_column_names = T
              , show_column_dend = F
              , show_row_dend = F
              , cluster_columns=T
              , cluster_rows=F
              , rect_gp = gpar(col = "white", lwd = 1)
              , row_names_gp = gpar(fontsize = 10)
)


######### 在线可视化
dim(hallmark.heatmap.dat)

pathways.sorted=colnames(hallmark.heatmap.dat)[column_order(fig5a)]

tcga.hallmark.c1.res_use=data.frame(Group='C1',tcga.hallmark.c1.res[na.omit(match(pathways.sorted,rownames(tcga.hallmark.c1.res))),c('ID','qvalues','NES')])
tcga.hallmark.c2.res_use=data.frame(Group='C2',tcga.hallmark.c2.res[na.omit(match(pathways.sorted,rownames(tcga.hallmark.c2.res))),c('ID','qvalues','NES')])
tcga.hallmark.c3.res_use=data.frame(Group='C3',tcga.hallmark.c3.res[na.omit(match(pathways.sorted,rownames(tcga.hallmark.c3.res))),c('ID','qvalues','NES')])
tcga.hallmark.c4.res_use=data.frame(Group='C4',tcga.hallmark.c4.res[na.omit(match(pathways.sorted,rownames(tcga.hallmark.c4.res))),c('ID','qvalues','NES')])

hallmark.forVisu=rbind(tcga.hallmark.c1.res_use
                       ,tcga.hallmark.c2.res_use
                       ,tcga.hallmark.c3.res_use
                       ,tcga.hallmark.c4.res_use)

rownames(hallmark.forVisu)=NULL

hallmark.forVisu$qvalues=-log10(hallmark.forVisu$qvalues)

head(hallmark.forVisu)
hallmark.forVisu=hallmark.forVisu[,c('ID','Group','qvalues','NES')]
range(hallmark.forVisu$NES)
range(hallmark.forVisu$qvalues)
writeMatrix(hallmark.forVisu,'files/hallmark.forVisu.txt',row = F)

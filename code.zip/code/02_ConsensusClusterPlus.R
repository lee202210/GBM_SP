############### 细胞衰老通路评分计算
## 获取 免疫打分
senescence_ssgsea=function(exp,gmt,isTCGA=T){
  library(GSVA)
  library(GSEABase)
  geneSets=GSEABase::getGmt(gmt)
  ssGSEA.immue <- GSVA::gsva(as.matrix(exp), gset.idx.list=geneSets
                             ,method='ssgsea',
                             min.sz=1, max.sz=Inf, verbose=TRUE)
  ssGSEA.immue=t(ssGSEA.immue)
  if(isTCGA){
    rnames=gsub('\\.','-',row.names(ssGSEA.immue))
    row.names(ssGSEA.immue)=rnames
  }
  return(ssGSEA.immue)
}

########## ssGSEA scores计算
gmts=list.files('origin_datas/SENESCENCE_MsigDB/',full.names=T)
dim(gbm.tcga.t.exp)
tcga.t.exp.sene.ssgsea=sapply(gmts, function(x){senescence_ssgsea(exp=gbm.tcga.t.exp,gmt=x)})
rownames(tcga.t.exp.sene.ssgsea)=colnames(gbm.tcga.t.exp)
colnames(tcga.t.exp.sene.ssgsea)=gsub(".*/(.*?)\\..*","\\1",colnames(tcga.t.exp.sene.ssgsea))
tcga.t.exp.sene.ssgsea=as.matrix(tcga.t.exp.sene.ssgsea)
tcga.t.exp.sene.ssgsea=t(tcga.t.exp.sene.ssgsea)
writeMatrix('files/文件/tcga.t.exp.sene.ssgsea.txt',dat = tcga.t.exp.sene.ssgsea)

########## 单因素
cox.pval=0.05
tcga.sene.ssgsea.cox=cox_batch(t(scale(t(as.matrix(tcga.t.exp.sene.ssgsea))))
                               ,time = gbm.tcga.t.exp.os$OS.time
                               , event = gbm.tcga.t.exp.os$OS)

table(tcga.sene.ssgsea.cox$p.value<0.05)
tcga.sene.ssgsea.cox=tcga.sene.ssgsea.cox[order(tcga.sene.ssgsea.cox$HR,decreasing = T),]

tcga.sene.ssgsea.sig=rownames(tcga.sene.ssgsea.cox)[which(tcga.sene.ssgsea.cox$p.value<cox.pval)]
length(tcga.sene.ssgsea.sig)

############## TCGA-GBM 单因素分析显著的森林图
tcga.sene.ssgsea.uni=tcga.sene.ssgsea.cox
tcga.sene.ssgsea.uni=signif(tcga.sene.ssgsea.uni,digits=3)
tcga.sene.ssgsea.uni$`Hazard Ratio(95%CI)`=paste0(tcga.sene.ssgsea.uni$HR,"(",tcga.sene.ssgsea.uni$`Low 95%CI`, "-", tcga.sene.ssgsea.uni$`High 95%CI`, ")")

########## 显著的senescence-related genes
tcga.sene.ssgsea.uni.sig=tcga.sene.ssgsea.uni[tcga.sene.ssgsea.sig,]
writeMatrix(tcga.sene.ssgsea.uni.sig,outpath = 'files/tcga.sene.ssgsea.uni.sig.txt')
writeMatrix(tcga.sene.ssgsea.uni,outpath = 'files/tcga.sene.ssgsea.uni.txt')
#############
tcga.t.exp.sene.ssgsea.sub=tcga.t.exp.sene.ssgsea[tcga.sene.ssgsea.sig,]
dim(tcga.t.exp.sene.ssgsea.sub)

####### 聚类
library(ConsensusClusterPlus)
#######
df_exp=tcga.t.exp.sene.ssgsea.sub
dim(df_exp)

clust_subtype = ConsensusClusterPlus(df_exp
                                     , maxK = 10, reps = 500
                                     , pItem = 0.8, pFeature = 1
                                     , title = "TCGA_subtype"
                                     , clusterAlg = 'pam'
                                     , seed = 123456789
                                     , distance = 'euclidean'
                                     , innerLinkage='ward.D2'
                                     , plot = "pdf", writeTable = T)

k1=4
tcga.subtype=data.frame(clust_subtype[[k1]]$consensusClass)
colnames(tcga.subtype)=c('Cluster')
tcga.subtype$Cluster=paste0('C',tcga.subtype$Cluster)
tcga.subtype$Cluster[tcga.subtype$Cluster=='C2']='CC1'
tcga.subtype$Cluster[tcga.subtype$Cluster=='C3']='CC2'
tcga.subtype$Cluster[tcga.subtype$Cluster=='C1']='CC3'
tcga.subtype$Cluster[tcga.subtype$Cluster=='C4']='CC4'
tcga.subtype$Cluster=gsub("CC","C",tcga.subtype$Cluster)
table(tcga.subtype)

library(survcomp)
fig1e=ggplotKMCox(data.frame(time = gbm.tcga.t.exp.os$OS.time/365
                             , event = gbm.tcga.t.exp.os$OS
                             , groups=tcga.subtype$Cluster)
                  , add_text = '')
fig1e

library(GSVA)
library(GSVAdata)
geneSets <- getGmt("./h.all.v7.4.symbols.gmt")

dim(gbm.tcga.exp)
range(gbm.tcga.exp)

tcga.exp.h.all <- gsva(as.matrix(gbm.tcga.exp), geneSets,min.sz=10,method='ssgsea')
tcga.exp.h.all <- data.frame(tcga.exp.h.all,check.names = F)

dim(gbm.cgga.t.exp.cmbt)
range(gbm.cgga.t.exp.cmbt)

cgga.exp.h.all <- gsva(as.matrix(gbm.cgga.t.exp.cmbt), geneSets,min.sz=10,method='ssgsea')
cgga.exp.h.all <- data.frame(cgga.exp.h.all)


dir.create('GSVA/')
save(tcga.exp.h.all,file = 'GSVA/tcga.exp.h.all.RData')
save(cgga.exp.h.all,file = 'GSVA/cgga.exp.h.all.RData')

############
library('GSVA')
library(GSEABase)
gmtFile='c2.cp.kegg.v7.4.symbols.gmt'
c2KEGG <- getGmt(gmtFile,
                 collectionType=BroadCollection(category="c2"),
                 geneIdType=SymbolIdentifier())
range(gbm.tcga.exp)
dim(gbm.tcga.exp)
tcga.kegg.ssgsea <- gsva(as.matrix(gbm.tcga.exp), 
                         c2KEGG,
                         method = 'ssgsea',
                         min.sz = 10,
                         max.sz = 500,
                         verbose = TRUE)
save(tcga.kegg.ssgsea,file = 'GSVA/tcga.kegg.ssgsea.RData')

library(IOBR)
library(EPIC)
library(estimate)

### CIBERSORT
tcga.exp.cibersort<-deconvo_cibersort(eset=gbm.tcga.exp,arrays=T)
cgga.exp.cibersort<-deconvo_cibersort(eset=cgga.exp,arrays=T)

save(tcga.exp.cibersort,file='immune/tcga.exp.cibersort.RData')
save(cgga.exp.cibersort,file='immune/cgga.exp.cibersort.RData')

#### ESTIMATE
tcga.exp.estimate<-deconvo_estimate(eset=gbm.tcga.exp)
cgga.exp.estimate<-deconvo_estimate(eset=cgga.exp)

save(tcga.exp.estimate,file='immune/tcga.exp.estimate.RData')
save(cgga.exp.estimate,file='immune/cgga.exp.estimate.RData')

##### xCell
tcga.exp.xcell<-deconvo_xcell(eset=gbm.tcga.exp,arrays=F)
cgga.exp.xcell<-deconvo_xcell(eset=cgga.exp,arrays=T)

save(tcga.exp.xcell,file='immune/tcga.exp.xcell.RData')
save(cgga.exp.xcell,file='immune/cgga.exp.xcell.RData')
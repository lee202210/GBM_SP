library(rpart)
library(rpart.plot)

tcga.group=tcga.subtype.ARS
tcga.group=factor(tcga.group$Cluster,levels = c('Low','High'))
table(tcga.group)

all.t.cli.forModel=cbind(tcga.t.cli_use,SRS.score=tcga.group,RiskScore=tcga.risk.score)

colnames(all.t.cli.forModel)

all.t.cli.forModel$Age1=factor(all.t.cli.forModel$Age1,levels = c('<=60','>60'))
all.t.cli.forModel$`IDH Mutation`=factor(all.t.cli.forModel$`IDH Mutation`,levels = c('Mutant','WT'))
str(all.t.cli.forModel)
colnames(all.t.cli.forModel)
table(all.t.cli.forModel$OS.time>0)

all.t.cli.forModel=all.t.cli.forModel[which(all.t.cli.forModel$OS.time>0),]

pfit <- rpart(Surv(OS.time, OS) ~ Age1 + Gender +`IDH Mutation`+`MGMT promoter methylation`+ SRS.score, data = all.t.cli.forModel)
print(pfit)
printcp(pfit)

pfit2 <- prune(pfit, cp=0.01)
print(pfit2)

pdf('PDFs/Fig11A.pdf',height = 8,width = 6)
rpart.plot(pfit2)
dev.off()

all.t.cli.forModel$class=pfit2$where
table(all.t.cli.forModel$class)


fit <- survfit( Surv(OS.time/365, OS) ~ class,data = all.t.cli.forModel)
library(survminer)
custom_theme <- function() {
  theme_survminer() %+replace%
    theme(
      plot.title=element_text(hjust=0.5)
    )
}
ggsurvplot(fit,data=all.t.cli.forModel,
                  conf.int = F,
                  pval = TRUE,
                  fun = "pct",
                  risk.table = TRUE,
                  size = 1,
                  title='',
                  ggtheme=custom_theme(),
                  linetype = "strata",
                  palette = pal_npg('nrc')(9)[4:1],
                  legend = "bottom",
                  legend.title = "SRS"
                  # legend.labs = c("HRS-high", "HRS-low",'HRS-M')
)
